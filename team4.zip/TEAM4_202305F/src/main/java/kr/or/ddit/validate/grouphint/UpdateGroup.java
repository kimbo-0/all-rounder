package kr.or.ddit.validate.grouphint;

import javax.validation.groups.Default;

public interface UpdateGroup extends Default{

}
