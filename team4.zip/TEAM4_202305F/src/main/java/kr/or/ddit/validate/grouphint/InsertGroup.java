package kr.or.ddit.validate.grouphint;

import javax.validation.groups.Default;

public interface InsertGroup extends Default{ //기본그룹을 상속받음
	
	/*
		인터페이스는 있는데 아무런 구성요소 없을 때 마커 인터페이스라고 함
		serializable도 마커 인터페이스
	*/



}
