package kr.or.ddit.vo.pms;

import lombok.Data;

@Data
public class MemoVO {

	private String memoBg;
	private Integer memoZindex;
	private Integer memoNo;
	private String memoCn;
	private String memoRgsde;
	private String memoBkmkYn;
	private Integer memoWidth;
	private Integer memoHeight;
	private Integer memoX;
	private Integer memoY;
	private String empCd;
}
