package kr.or.ddit.validate.grouphint;

public interface DeleteGroup {

}
