package kr.or.ddit.vo.groupware;

import lombok.Data;

@Data
public class AnnualVO {
	private String deptName;
	private String rankNm;
	private String empName;
}
