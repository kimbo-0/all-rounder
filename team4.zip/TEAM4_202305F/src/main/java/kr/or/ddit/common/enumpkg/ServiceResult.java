package kr.or.ddit.common.enumpkg;

public enum ServiceResult {
	OK, FAIL, PKDUPLICATED, NOTEXIST, INVALIDPASSWORD, CANNOTPROCEED

}
