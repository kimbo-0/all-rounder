package kr.or.ddit.vo.groupware;

import lombok.Data;

@Data
public class VacationVO {
	private String vSday;
	private String empCd;
	private String vFlag;
	private String vWhy;
	private String vEday;
}
