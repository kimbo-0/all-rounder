package kr.or.ddit.vo;

import lombok.Data;

@Data
public class FileAuthorVO {

	private String faTy;
	private Integer webSnm;
	private String webCours;
	private String faNm;
}
