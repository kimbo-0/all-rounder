package kr.or.ddit.vo;

import lombok.Data;

@Data
public class CommonVO {
	
	private String commonCodeCd;
	private String commonCodeUpperCd;
	private String commonCodeSj;
	private String commonCodeEnglSj;
	private String commonCodeUseAt;
}
