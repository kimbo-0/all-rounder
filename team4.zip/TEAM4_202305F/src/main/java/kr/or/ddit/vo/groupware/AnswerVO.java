package kr.or.ddit.vo.groupware;

import lombok.Data;

@Data
public class AnswerVO {
	
	private String answerCode;
	private String answerWrter;
	private String answerRgsde;
	private String answerCn;
	private Integer bbsNo;
	private String answerUpcode;
	
	private String answerWrterName;
}
